# Pendientes Criticos para Activar Monetizacion

Este checklist concentra los pendientes de integracion final para pasar de base funcional a operacion comercial completa.

## 1) Wiring UI-Backend
- [ ] Conectar la UI al backend con wiring completo.
- [ ] Conectar botones a motores.
- [ ] Conectar formularios a pricing, funnels y automatizaciones.
- [ ] Conectar dashboard a metricas, alertas y eventos.
- [ ] Conectar checkout al pricing engine.
- [ ] Conectar panel de automatizacion al EventBus.

## 2) Validacion integral de flujo
Flujo objetivo:
Landing -> Onboarding -> Dashboard -> Producto -> Contenido -> Lead -> Funnel -> Pricing -> Checkout -> Automatizacion

Checklist:
- [ ] Validar flujo completo de integracion extremo a extremo.
- [ ] Validar estados: loading, error, success.
- [ ] Validar tipos de datos y nulls.
- [ ] Validar emision de eventos.

## 3) Pruebas de estres
Objetivos minimos:
- [ ] 1000 eventos.
- [ ] 100 leads.
- [ ] 50 productos.
- [ ] 20 funnels.
- [ ] 10 automatizaciones simultaneas.

## 4) Pruebas de demo
- [ ] Ejecutar comandos oficiales del README.
- [ ] Validar salida en pantalla.
- [ ] Confirmar cero errores en consola.
- [ ] Validar dashboards.

## 5) Cierre final
- [ ] Congelar version.
- [ ] Generar build.
- [ ] Validar build.
- [ ] Preparar demo.
- [ ] Preparar pitch.
- [ ] Preparar pricing.
- [ ] Preparar onboarding.

## Criterio de salida
Se considera activacion lista cuando todas las casillas esten completas y la suite de validacion operativa se ejecute sin errores.
